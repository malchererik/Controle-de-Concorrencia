import threading
import time
import random
import networkx as nx
from queue import Queue
from datetime import datetime

# Um grafo que mostra quem está esperando por quem
grafo_espera = nx.DiGraph()
# Um lock para evitar bagunça quando várias transações mexem nele
lock_grafo = threading.Lock()

class Recurso:
    def __init__(self, nome):
        # Um recurso com um nome e uma fila para quem está esperando
        self.nome = nome
        self.lock = threading.Lock()
        self.dono = None
        self.fila_espera = Queue()

    def tentar_bloquear(self, transacao):
        # Tenta pegar/lockar o recurso para a transação
        print(f" {transacao.nome} quer usar {self.nome}... ")
        if self.lock.acquire(blocking=False):
            self.dono = transacao
            print(f" {transacao.nome} pegou {self.nome}! ✅ ")
            return True
        else:
            # Coloca a transação na fila e atualiza a fila de espera
            print(f" {transacao.nome} está esperando por {self.nome}. ")
            self.fila_espera.put(transacao)
            with lock_grafo:
                grafo_espera.add_edge(transacao.nome, self.dono.nome)
            return False

    def liberar(self, transacao):
        # Libera o recurso de antes se for a transação certa
        if self.dono == transacao:
            self.lock.release()
            print(f" {transacao.nome} soltou {self.nome}. ")
            self.dono = None
            # Limpa o mapa e chama a próxima transação da fila
            with lock_grafo:
                grafo_espera.remove_edges_from([(t, transacao.nome) for t in grafo_espera.predecessors(transacao.nome)])
            if not self.fila_espera.empty():
                proxima_transacao = self.fila_espera.get()
                proxima_transacao.evento_espera.set()

class Transacao(threading.Thread):
    def __init__(self, nome, saldo_conta, limite_credito):
        # Prepara uma transação com nome e recursos que ela precisa
        super().__init__()
        self.nome = nome
        self.tempo_inicio = datetime.now().timestamp()
        self.saldo_conta = saldo_conta
        self.limite_credito = limite_credito
        self.evento_espera = threading.Event()
        self.ativa = True

    def run(self):
        # Faz a transação rodar até terminar
        while self.ativa:
            print(f" {self.nome} começando uma nova transação...")
            time.sleep(random.uniform(0.1, 1.0))  # Serve para esperar um pouco

            # Tenta pegar o saldo da conta
            if not self._tentar_acesso(self.saldo_conta):
                if self._tem_deadlock():
                    self._resolver_deadlock()
                    continue
                self.evento_espera.wait()  # Espera até o recurso ficar livre
                if not self.ativa:
                    continue
                self.saldo_conta.tentar_bloquear(self)

            print(f" {self.nome} olhou o saldo da conta.")
            time.sleep(random.uniform(0.1, 0.5))  #outra pausa

            # Tenta pegar o limite de crédito
            if not self._tentar_acesso(self.limite_credito):
                if self._tem_deadlock():
                    self._resolver_deadlock()
                    continue
                self.evento_espera.wait()  # Espera até o recurso ficar livre
                if not self.ativa:
                    continue
                self.limite_credito.tentar_bloquear(self)

            print(f" {self.nome} olhou o limite de crédito.")
            time.sleep(random.uniform(0.1, 0.5))  

            # Atualiza o saldo e o limite
            print(f" {self.nome} mudou o saldo da conta.")
            print(f" {self.nome} mudou o limite de crédito.")
            time.sleep(random.uniform(0.1, 0.5))  

            # Libera os dois recursos
            self.saldo_conta.liberar(self)
            self.limite_credito.liberar(self)

            print(f" {self.nome} terminouA a transação com sucesso!")
            self.ativa = False  # Finaliza a transação

    def _tentar_acesso(self, recurso):
        # Verifica se pode pegar o recurso ou se precisa desistir da transação por causa do deadlock
        if recurso.dono and recurso.dono != self:
            if self.tempo_inicio > recurso.dono.tempo_inicio:
                print(f" {self.nome} foi cancelada ao tentar usar {recurso.nome}. Vai tentar de novo.")
                self._abortar()
                return False
        return recurso.tentar_bloquear(self)

    def _tem_deadlock(self):
        # Checa se as transações estão travadas 
        with lock_grafo:
            try:
                nx.find_cycle(grafo_espera)
                print(f" Problema! {self.nome} está em um travamento! ")
                return True
            except nx.NetworkXNoCycle:
                return False

    def _resolver_deadlock(self):
        # Resolve o travamento cancelando a transação mais nova
        with lock_grafo:
            try:
                ciclo = nx.find_cycle(grafo_espera)
                transacao_recente = max(
                    [t for t in grafo_espera.nodes if any(n in [x[0] for x in ciclo] for n in grafo_espera.successors(t))],
                    key=lambda t: grafo_espera.nodes[t].get('timestamp', float('inf'))
                )
                print(f" {transacao_recente} vai ser cancelada para destravar.")
                grafo_espera.nodes[transacao_recente]['objeto']._abortar()
            except nx.NetworkXNoCycle:
                pass

    def _abortar(self):
        # Cancela a transação e começa de novo
        self.ativa = False
        if self.saldo_conta.dono == self:
            self.saldo_conta.liberar(self)
        if self.limite_credito.dono == self:
            self.limite_credito.liberar(self)
        print(f" {self.nome} foi cancelada. Tentando novamente... ")
        self.evento_espera.clear()  # Limpa a espera
        self.ativa = True
        self.tempo_inicio = datetime.now().timestamp()
        self.start()  # Começa a transação novamente

def main():
    # Cria os recursos e começa as transações
    saldo_conta = Recurso("Saldo da Conta")
    limite_credito = Recurso("Limite de Crédito")
    transacoes = []

    # Cria e começa as quatro transações
    for i in range(4):
        t = Transacao(f"Transação {i+1}", saldo_conta, limite_credito)
        grafo_espera.add_node(t.nome, objeto=t, timestamp=t.tempo_inicio)
        transacoes.append(t)
        t.start()

    # Espera todas as transações terminarem
    for t in transacoes:
        t.join()

if __name__ == "__main__":
    # Roda o programa se for chamado diretamente
    main()

