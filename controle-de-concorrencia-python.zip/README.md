# Controle de Concorrência com Prevenção de Deadlock

Este projeto simula controle de concorrência entre transações usando múltiplas threads em Python. Inclui detecção e prevenção de deadlock usando grafos de espera.

## 📁 Arquivos

- `main.py`: Código-fonte principal com as classes `Recurso`, `Transacao` e lógica de execução.
- `README.md`: Este arquivo, com as instruções de uso.

## ▶️ Como executar

### Requisitos:
- Python 3.7 ou superior
- Biblioteca necessária:
  ```bash
  pip install networkx
  ```

### Execução:
```bash
python main.py
```

O programa simula 4 transações acessando recursos compartilhados com gerenciamento de locks e detecção de deadlocks em tempo real.

## 💡 Funcionalidades

- Controle de concorrência com `threading`.
- Lock de recursos com fila de espera.
- Grafo de espera implementado com `networkx`.
- Detecção e resolução de deadlock baseada na transação mais nova.

## 👤 Autor

- Erik Malcher
- GitHub: [@malchererik](https://github.com/malchererik)
- Email: malcher@edu.univali.br
