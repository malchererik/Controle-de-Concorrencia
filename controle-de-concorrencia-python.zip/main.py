import threading
import time
import random
import networkx as nx
from queue import Queue
from datetime import datetime

grafo_espera = nx.DiGraph()
lock_grafo = threading.Lock()

class Recurso:
    def __init__(self, nome):
        self.nome = nome
        self.lock = threading.Lock()
        self.dono = None
        self.fila_espera = Queue()

    def tentar_bloquear(self, transacao):
        print(f" {transacao.nome} quer usar {self.nome}... ")
        if self.lock.acquire(blocking=False):
            self.dono = transacao
            print(f" {transacao.nome} pegou {self.nome}! ✅ ")
            return True
        else:
            print(f" {transacao.nome} está esperando por {self.nome}. ")
            self.fila_espera.put(transacao)
            with lock_grafo:
                grafo_espera.add_edge(transacao.nome, self.dono.nome)
            return False

    def liberar(self, transacao):
        if self.dono == transacao:
            self.lock.release()
            print(f" {transacao.nome} soltou {self.nome}. ")
            self.dono = None
            with lock_grafo:
                grafo_espera.remove_edges_from([(t, transacao.nome) for t in grafo_espera.predecessors(transacao.nome)])
            if not self.fila_espera.empty():
                proxima_transacao = self.fila_espera.get()
                proxima_transacao.evento_espera.set()

class Transacao(threading.Thread):
    def __init__(self, nome, saldo_conta, limite_credito):
        super().__init__()
        self.nome = nome
        self.tempo_inicio = datetime.now().timestamp()
        self.saldo_conta = saldo_conta
        self.limite_credito = limite_credito
        self.evento_espera = threading.Event()
        self.ativa = True

    def run(self):
        while self.ativa:
            print(f" {self.nome} começando uma nova transação...")
            time.sleep(random.uniform(0.1, 1.0))
            if not self._tentar_acesso(self.saldo_conta):
                if self._tem_deadlock():
                    self._resolver_deadlock()
                    continue
                self.evento_espera.wait()
                if not self.ativa:
                    continue
                self.saldo_conta.tentar_bloquear(self)

            print(f" {self.nome} olhou o saldo da conta.")
            time.sleep(random.uniform(0.1, 0.5))

            if not self._tentar_acesso(self.limite_credito):
                if self._tem_deadlock():
                    self._resolver_deadlock()
                    continue
                self.evento_espera.wait()
                if not self.ativa:
                    continue
                self.limite_credito.tentar_bloquear(self)

            print(f" {self.nome} olhou o limite de crédito.")
            time.sleep(random.uniform(0.1, 0.5))

            print(f" {self.nome} mudou o saldo da conta.")
            print(f" {self.nome} mudou o limite de crédito.")
            time.sleep(random.uniform(0.1, 0.5))

            self.saldo_conta.liberar(self)
            self.limite_credito.liberar(self)

            print(f" {self.nome} terminouA a transação com sucesso!")
            self.ativa = False

    def _tentar_acesso(self, recurso):
        if recurso.dono and recurso.dono != self:
            if self.tempo_inicio > recurso.dono.tempo_inicio:
                print(f" {self.nome} foi cancelada ao tentar usar {recurso.nome}. Vai tentar de novo.")
                self._abortar()
                return False
        return recurso.tentar_bloquear(self)

    def _tem_deadlock(self):
        with lock_grafo:
            try:
                nx.find_cycle(grafo_espera)
                print(f" Problema! {self.nome} está em um travamento! ")
                return True
            except nx.NetworkXNoCycle:
                return False

    def _resolver_deadlock(self):
        with lock_grafo:
            try:
                ciclo = nx.find_cycle(grafo_espera)
                transacao_recente = max(
                    [t for t in grafo_espera.nodes if any(n in [x[0] for x in ciclo] for n in grafo_espera.successors(t))],
                    key=lambda t: grafo_espera.nodes[t].get('timestamp', float('inf'))
                )
                print(f" {transacao_recente} vai ser cancelada para destravar.")
                grafo_espera.nodes[transacao_recente]['objeto']._abortar()
            except nx.NetworkXNoCycle:
                pass

    def _abortar(self):
        self.ativa = False
        if self.saldo_conta.dono == self:
            self.saldo_conta.liberar(self)
        if self.limite_credito.dono == self:
            self.limite_credito.liberar(self)
        print(f" {self.nome} foi cancelada. Tentando novamente... ")
        self.evento_espera.clear()
        self.ativa = True
        self.tempo_inicio = datetime.now().timestamp()
        self.start()

def main():
    saldo_conta = Recurso("Saldo da Conta")
    limite_credito = Recurso("Limite de Crédito")
    transacoes = []

    for i in range(4):
        t = Transacao(f"Transação {i+1}", saldo_conta, limite_credito)
        grafo_espera.add_node(t.nome, objeto=t, timestamp=t.tempo_inicio)
        transacoes.append(t)
        t.start()

    for t in transacoes:
        t.join()

if __name__ == "__main__":
    main()
